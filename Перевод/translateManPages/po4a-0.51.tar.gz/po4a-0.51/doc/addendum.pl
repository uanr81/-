PO4A-HEADER:mode=after;position=^=head1 AUTORZY;beginboundary=^=head1

=head1 TŁUMACZENIE

 Robert Luberda <robert@debian.org>


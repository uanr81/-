PO4A-HEADER:mode=after;position=^\.SH AUTOR;beginboundary=^\.SH

.SH TŁUMACZENIE

Robert Luberda <robert@debian.org>

